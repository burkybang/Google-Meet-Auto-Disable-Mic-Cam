window.onload = () => {
  const disableCameraButton = document.querySelector('div[role="button"][aria-label$=" + e)"][data-is-muted="false"]');
  if (disableCameraButton)
    disableCameraButton.click();
};